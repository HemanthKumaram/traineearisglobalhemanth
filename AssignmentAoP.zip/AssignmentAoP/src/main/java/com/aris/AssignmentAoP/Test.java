package com.aris.AssignmentAoP;

import org.springframework.stereotype.Component;
@Component
public class Test {
	

	public void main()
	{
		System.out.println("Test Function");
	}
}