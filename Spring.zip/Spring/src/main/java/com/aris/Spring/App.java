package com.aris.Spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context = new AnnotationConfigApplicationContext(config.class);
       Greetingservic gt = context.getBean(Greetingservic.class);
       gt.greeting();
    }
}
