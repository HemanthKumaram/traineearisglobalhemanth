package com.aris.Spring;

public interface Greeting {

	public String greet();
}

